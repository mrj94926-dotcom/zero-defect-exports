-- ============================================
-- COMPLETE SUPABASE SETUP FOR ZERO DEFECT
-- Run this in your Supabase SQL Editor
-- This creates all tables with proper RLS policies
-- ============================================

-- ============================================
-- 1. INQUIRIES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS inquiries (
  id BIGINT PRIMARY KEY,
  inquiry_number TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  company TEXT,
  country TEXT NOT NULL,
  city TEXT,
  product TEXT NOT NULL,
  quantity TEXT,
  subject TEXT,
  message TEXT,
  product_interest TEXT,
  status TEXT DEFAULT 'pending',
  priority TEXT DEFAULT 'medium',
  assigned_to TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),
  timestamp TIMESTAMP DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_inquiries_email ON inquiries(email);
CREATE INDEX IF NOT EXISTS idx_inquiries_country ON inquiries(country);
CREATE INDEX IF NOT EXISTS idx_inquiries_status ON inquiries(status);
CREATE INDEX IF NOT EXISTS idx_inquiries_created_at ON inquiries(created_at DESC);

ALTER TABLE inquiries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable insert for anon users" ON inquiries;
DROP POLICY IF EXISTS "Enable read for all users" ON inquiries;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON inquiries;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON inquiries;

CREATE POLICY "Enable insert for anon users" ON inquiries
FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read for all users" ON inquiries
FOR SELECT USING (true);

CREATE POLICY "Enable update for authenticated users" ON inquiries
FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Enable delete for authenticated users" ON inquiries
FOR DELETE USING (true);

-- ============================================
-- 2. SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS settings (
  id TEXT PRIMARY KEY DEFAULT 'default',
  store_name TEXT,
  store_email TEXT,
  store_phone TEXT,
  store_whatsapp TEXT,
  store_location TEXT,
  business_hours_weekdays TEXT,
  business_hours_saturday TEXT,
  business_hours_sunday TEXT,
  social_linkedin TEXT,
  social_twitter TEXT,
  social_instagram TEXT,
  social_facebook TEXT,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_settings_id ON settings(id);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow all read" ON settings;
DROP POLICY IF EXISTS "Allow all update" ON settings;
DROP POLICY IF EXISTS "Allow all insert" ON settings;

CREATE POLICY "Allow all read" ON settings
FOR SELECT USING (true);

CREATE POLICY "Allow all update" ON settings
FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Allow all insert" ON settings
FOR INSERT WITH CHECK (true);

INSERT INTO settings (id, store_name, store_email, store_phone, store_whatsapp, store_location, 
  business_hours_weekdays, business_hours_saturday, business_hours_sunday)
VALUES (
  'default',
  'Zero Defect Export & Manufacturing',
  'export@zerodefect.com',
  '+91 XXX XXX XXXX',
  '+91 XXX XXX XXXX',
  'India',
  'Monday - Friday: 9:00 AM - 6:00 PM IST',
  'Saturday: 10:00 AM - 4:00 PM IST',
  'Sunday: Closed'
)
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 3. REVIEWS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS reviews (
  id BIGINT PRIMARY KEY,
  reviewer_name TEXT NOT NULL,
  rating NUMERIC(2, 1) NOT NULL,
  review_text TEXT NOT NULL,
  reviewer_image TEXT,
  product_name TEXT DEFAULT 'General Review',
  is_approved BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);
CREATE INDEX IF NOT EXISTS idx_reviews_approved ON reviews(is_approved);
CREATE INDEX IF NOT EXISTS idx_reviews_created_at ON reviews(created_at DESC);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable insert for anon users" ON reviews;
DROP POLICY IF EXISTS "Enable read for all users" ON reviews;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON reviews;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON reviews;

CREATE POLICY "Enable insert for anon users" ON reviews
FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read for all users" ON reviews
FOR SELECT USING (true);

CREATE POLICY "Enable update for authenticated users" ON reviews
FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Enable delete for authenticated users" ON reviews
FOR DELETE USING (true);

-- ============================================
-- 4. PRODUCTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS products (
  id BIGINT PRIMARY KEY,
  name TEXT NOT NULL,
  subtitle TEXT,
  category TEXT NOT NULL,
  price NUMERIC(10, 2) NOT NULL,
  stock INTEGER DEFAULT 0,
  image TEXT,
  is_best_seller BOOLEAN DEFAULT false,
  sub_category TEXT,
  is_new BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable insert for anon users" ON products;
DROP POLICY IF EXISTS "Enable read for all users" ON products;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON products;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON products;

CREATE POLICY "Enable insert for anon users" ON products
FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read for all users" ON products
FOR SELECT USING (true);

CREATE POLICY "Enable update for authenticated users" ON products
FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Enable delete for authenticated users" ON products
FOR DELETE USING (true);

-- ============================================
-- 5. ORDERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS orders (
  id BIGINT PRIMARY KEY,
  order_number TEXT UNIQUE NOT NULL,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT,
  shipping_address TEXT,
  product_name TEXT,
  quantity INTEGER,
  unit_price NUMERIC(10, 2),
  total_amount NUMERIC(10, 2),
  payment_method TEXT,
  status TEXT DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),
  timestamp TIMESTAMP DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_email ON orders(customer_email);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable insert for anon users" ON orders;
DROP POLICY IF EXISTS "Enable read for all users" ON orders;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON orders;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON orders;

CREATE POLICY "Enable insert for anon users" ON orders
FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read for all users" ON orders
FOR SELECT USING (true);

CREATE POLICY "Enable update for authenticated users" ON orders
FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Enable delete for authenticated users" ON orders
FOR DELETE USING (true);

-- ============================================
-- 6. NOTIFICATIONS TABLE (FIXED FOR ANON ACCESS)
-- ============================================
CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT,
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow authenticated users to read notifications" ON notifications;
DROP POLICY IF EXISTS "Allow authenticated users to insert notifications" ON notifications;
DROP POLICY IF EXISTS "Allow authenticated users to update notifications" ON notifications;
DROP POLICY IF EXISTS "Allow authenticated users to delete notifications" ON notifications;
DROP POLICY IF EXISTS "Enable insert for all users" ON notifications;
DROP POLICY IF EXISTS "Enable read for all users" ON notifications;
DROP POLICY IF EXISTS "Enable update for all users" ON notifications;
DROP POLICY IF EXISTS "Enable delete for all users" ON notifications;

CREATE POLICY "Enable insert for all users" ON notifications
FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read for all users" ON notifications
FOR SELECT USING (true);

CREATE POLICY "Enable update for all users" ON notifications
FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Enable delete for all users" ON notifications
FOR DELETE USING (true);

-- ============================================
-- 7. ADMIN PROFILES TABLE (FIXED FOR ANON ACCESS)
-- ============================================
CREATE TABLE IF NOT EXISTS admin_profiles (
    id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_email TEXT UNIQUE NOT NULL,
    name TEXT,
    avatar_url TEXT,
    role TEXT DEFAULT 'admin',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_admin_profiles_email ON admin_profiles(user_email);

ALTER TABLE admin_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow authenticated users to read admin profiles" ON admin_profiles;
DROP POLICY IF EXISTS "Allow authenticated users to insert admin profiles" ON admin_profiles;
DROP POLICY IF EXISTS "Allow authenticated users to update admin profiles" ON admin_profiles;
DROP POLICY IF EXISTS "Allow authenticated users to delete admin profiles" ON admin_profiles;
DROP POLICY IF EXISTS "Enable insert for all users" ON admin_profiles;
DROP POLICY IF EXISTS "Enable read for all users" ON admin_profiles;
DROP POLICY IF EXISTS "Enable update for all users" ON admin_profiles;
DROP POLICY IF EXISTS "Enable delete for all users" ON admin_profiles;

CREATE POLICY "Enable insert for all users" ON admin_profiles
FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read for all users" ON admin_profiles
FOR SELECT USING (true);

CREATE POLICY "Enable update for all users" ON admin_profiles
FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Enable delete for all users" ON admin_profiles
FOR DELETE USING (true);

-- ============================================
-- VERIFICATION QUERIES
-- ============================================
-- Run these to verify everything is set up correctly:

-- Check all tables exist
-- SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;

-- Check RLS is enabled on all tables
-- SELECT tablename, rowsecurity FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;

-- Check all policies
-- SELECT tablename, policyname, permissive, roles, qual, with_check FROM pg_policies WHERE schemaname = 'public' ORDER BY tablename;

-- Count records in each table
-- SELECT 'inquiries' as table_name, COUNT(*) as count FROM inquiries
-- UNION ALL SELECT 'settings', COUNT(*) FROM settings
-- UNION ALL SELECT 'reviews', COUNT(*) FROM reviews
-- UNION ALL SELECT 'products', COUNT(*) FROM products
-- UNION ALL SELECT 'orders', COUNT(*) FROM orders
-- UNION ALL SELECT 'notifications', COUNT(*) FROM notifications
-- UNION ALL SELECT 'admin_profiles', COUNT(*) FROM admin_profiles;
